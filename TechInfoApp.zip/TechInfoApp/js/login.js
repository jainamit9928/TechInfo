const login = (username,password) => {
	if(username  !== "amit" && password !== "jain"){
	console.log("wrong crendentila")
	}
	console.log("valid")
}

export {login}