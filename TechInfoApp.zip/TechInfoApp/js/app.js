import {login} from './login'
login("amit","adns")

/*require("../css/bootstrap.css");
require("../css/app.less");*/
//debugger;
document.write("welcome to webpack");

console.log("APP JS");


